﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace APM
{
    public partial class Form_Authentication : Form
    {
        //Declaring Form_Navigation
        Form_Navigation navigationPage = new Form_Navigation();
        
        public Form_Authentication()
        {
            InitializeComponent();
            textBox_Password.PasswordChar = '*';
           
           
        }
        
        private void Label1_Click(object sender, EventArgs e)
        {

        }
        // --Closing button for the Login Page
        private void Button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        // --This basically instantiates the Navigation form/page
        // --It is Commenced by hiding the Login Page after successful login
        // --Access is then granted to next page


       

        private void ENTER(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (Char)Keys.Enter)
            {
                button_Login.PerformClick();
            }
        }
        private void button_Login_Click(object sender, EventArgs e)
        {
            

            if (textBox_Password.Text == "1")
            {
                this.Hide();
                navigationPage.Show();
                
            }
            else
            {
                MessageBox.Show("The password that you've entered is incorrect", "Access Denied!", MessageBoxButtons.RetryCancel);
            }
        }
        


        private void Form_Authentication_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox_Password_TextChanged(object sender, EventArgs e)
        {

        }

       
    }
}
